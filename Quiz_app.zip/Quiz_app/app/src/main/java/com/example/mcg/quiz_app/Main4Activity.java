package com.example.mcg.quiz_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Main4Activity extends AppCompatActivity {

    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        bundle = savedInstanceState;
        bundle = getIntent().getExtras();

    }

    public void addScore4(View view)
    {
        bundle = getIntent().getExtras();

        RadioButton radiobutton_a = (RadioButton)findViewById(R.id.q4_radio_button_a);
        RadioButton radiobutton_c = (RadioButton)findViewById(R.id.q4_radio_button_c);


        int score=0;
        String answer;
        Intent intent = new Intent(Main4Activity.this,Main5Activity.class);

        if(radiobutton_a.isChecked())
        {
            score+=5;
        }
        if(radiobutton_c.isChecked())
        {
            score+=5;
        }

        score =score + bundle.getInt("score");
        intent.putExtra("score",score);
       Main4Activity.this.startActivity(intent);


    }
}
