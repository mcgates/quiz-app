package com.example.mcg.quiz_app;

import android.content.Intent;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    int question_no = 1,score=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void addScore(View view)
    {
        RadioButton radiobutton1 = (RadioButton)findViewById(R.id.q1_radio_button_a);
        RadioButton radiobutton2 = (RadioButton)findViewById(R.id.q1_radio_button_b);
        RadioButton radiobutton3 = (RadioButton)findViewById(R.id.q1_radio_button_c);
        RadioButton radiobutton4 = (RadioButton)findViewById(R.id.q1_radio_button_d);
        TextView Questionextview = (TextView)findViewById(R.id.quiz_text_view);

        Intent intent = new Intent(MainActivity.this,Main2Activity.class);



            if (radiobutton1.isChecked()) { score = score + 10;
                intent.putExtra("score",score);
                MainActivity.this.startActivity(intent); } else
                    if (radiobutton2.isChecked()) {
                        intent.putExtra("score",score);
                        MainActivity.this.startActivity(intent);} else
                    if (radiobutton3.isChecked()) {
                        intent.putExtra("score",score);
                        MainActivity.this.startActivity(intent);} else
                    if (radiobutton4.isChecked()) {
                        intent.putExtra("score",score);
                        MainActivity.this.startActivity(intent); }else

            {
                Toast.makeText(MainActivity.this, R.string.invalid_selection, Toast.LENGTH_SHORT).show();
                question_no = 0;
            }
        }

    public void quizStart(View view) {
    }
}


