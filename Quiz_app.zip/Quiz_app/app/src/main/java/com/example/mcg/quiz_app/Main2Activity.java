package com.example.mcg.quiz_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    Bundle bundle;
    int score=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        bundle=savedInstanceState;          //previous activity info
        bundle = getIntent().getExtras();   //save to a variable
        score = bundle.getInt("score"); //get score from precious activitu

    }

    public void addScore2(View view)
    {

        String answer;
        Intent intent = new Intent(Main2Activity.this,Main3Activity.class);     //prepare next activity

        EditText edittext = (EditText)findViewById(R.id.quiz_edit_text);
        answer = edittext.getText().toString().trim();      //read text



        if(answer.equals("Spain"))          //check answer
        {

            score = 10 + bundle.getInt("score");

        }else
        {
            score = bundle.getInt("score");
        }

        intent.putExtra("score",score);     //transfer score value to intent(next activity)
        Main2Activity.this.startActivity(intent); //goto next activity


    }

}
