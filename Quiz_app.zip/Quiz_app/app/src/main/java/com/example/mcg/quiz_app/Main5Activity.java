package com.example.mcg.quiz_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main5Activity extends AppCompatActivity {

        Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        bundle = savedInstanceState;
        bundle = getIntent().getExtras();
         //score = savedInstanceState.getInt("score");
        display();


    }

    public void display()
    {
        int score;
        score = bundle.getInt("score");
        TextView textview = (TextView)findViewById(R.id.score_textview);
       textview.setText(String.valueOf(score)+"/40");

       TextView result = (TextView)findViewById(R.id.won_testview);

       if(score > 20)
       {
         result.setText(R.string.congrats);
       }else
       {
           result.setText("You Lost");
       }
    }
    public void quizStart()
    {
        //Intent intent = new Intent(Main5Activity.this,MainActivity.class);
        //Main5Activity.this.startActivity(intent);
    }
}
