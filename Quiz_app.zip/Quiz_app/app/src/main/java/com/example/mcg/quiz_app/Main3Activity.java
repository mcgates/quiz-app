package com.example.mcg.quiz_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        bundle = savedInstanceState;
        bundle = getIntent().getExtras();




    }


    public void addScore3(View view)
    {



        int score=0;
        String answer;
        Intent intent = new Intent(Main3Activity.this,Main4Activity.class);

        EditText edittext = (EditText)findViewById(R.id.q_edit_text);

        answer = edittext.getText().toString();

       if(answer.equals("2022"))
        {
            score = 10;
            score +=  bundle.getInt("score");
        }else
       {
           score =  bundle.getInt("score");
       }


        intent.putExtra("score",score);
        Main3Activity.this.startActivity(intent);
    }
}
